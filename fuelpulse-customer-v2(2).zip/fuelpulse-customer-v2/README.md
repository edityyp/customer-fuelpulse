# FuelPulse — Customer Rewards & Receipt Verification (V2)

A completely independent FuelPulse application for Kalash Filling Stations users. This repository is separate from the existing production FuelPulse app and is designed for a **new Supabase project/database**, independent authentication, and independent deployment.

## What this app does

Users scan a fuel Parchi, the app extracts QR/OCR fields, and the backend verifies them against a trusted Kalash station/POS transaction record before awarding points. OCR is never treated as proof.

Core user loop: **Scan Parchi → Secure backend verification → Earn points → Track vehicles → Discover offers**.

## Roles

Only three application roles exist:

- `USER` — consumer fuel buyer
- `MANAGER` — station operations and manual review
- `OWNER` — organization-wide settings and controls

There is no Employee role, dashboard, terminology, or permission model in V2.

## Architecture

- Mobile-first React/Vite frontend
- Fastify backend API
- Supabase phone auth in production
- New Supabase schema in `supabase/migrations`
- Server-side verification and role checks
- Private receipt image storage
- Immutable points ledger and audit logs
- Fraud/risk evaluation layer

## Security principle

Never award points from OCR alone. The trusted station transaction record is authoritative.

Verification checks include token/invoice, station, vehicle, mobile, amount, volume, timestamp, expiry, replay, idempotency, velocity, and duplicate image signals.

## Supabase setup

1. Create a **new Supabase project** for V2.
2. Apply migrations from `supabase/migrations`.
3. Enable Supabase phone OTP.
4. Create a private bucket named by `PRIVATE_RECEIPT_BUCKET`.
5. Add environment variables from `.env.example`.
6. Keep `SUPABASE_SERVICE_ROLE_KEY` server-side only.

## Local development

```bash
npm install
cp .env.example .env
npm run dev
npm run server
npm test
npm run build
```

## Important constraints

- Do not connect this frontend to the old FuelPulse production database.
- Do not modify old production migrations or repositories.
- Receipt validity is configurable (`receipt_validity_minutes`, default 20).
- Receipt redemption and points award must be one atomic backend operation in production.

## Testing coverage

Automated tests cover receipt parsing, normalizers, valid redemption, expiry, future receipts, invalid invoice, duplicate redemption, idempotency, vehicle mismatch, mobile mismatch, amount mismatch, station mismatch, duplicate image risk, role authorization, token randomness, and PII masking.
