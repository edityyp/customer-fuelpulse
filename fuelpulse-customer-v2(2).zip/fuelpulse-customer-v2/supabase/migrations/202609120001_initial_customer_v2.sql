-- FuelPulse Customer V2 independent schema. Apply to a NEW Supabase project only.
create extension if not exists pgcrypto;

create type public.app_role as enum ('USER','MANAGER','OWNER');
create type public.account_status as enum ('ACTIVE','SUSPENDED','PENDING');
create type public.receipt_status as enum ('PENDING','VERIFIED','REDEEMED','EXPIRED','REJECTED','REVIEW_REQUIRED');
create type public.redemption_status as enum ('SUCCESS','FAILED','REVIEW_REQUIRED');
create type public.review_status as enum ('OPEN','APPROVED','REJECTED','CORRECTION_REQUESTED');
create type public.audit_action as enum ('USER_REGISTERED','VEHICLE_ADDED','RECEIPT_SCANNED','RECEIPT_VERIFICATION_FAILED','RECEIPT_VERIFIED','POINTS_AWARDED','RECEIPT_REDEEMED','DUPLICATE_REDEMPTION_ATTEMPT','FRAUD_FLAGGED','MANUAL_REVIEW_CREATED','MANAGER_APPROVED','MANAGER_REJECTED','OFFER_CREATED','OFFER_UPDATED');

create table public.organizations (id uuid primary key default gen_random_uuid(), name text not null, slug text not null unique, created_at timestamptz not null default now());
create table public.stations (id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id), name text not null, address text, fcc_id text, active boolean not null default true, created_at timestamptz not null default now());
create table public.app_settings (organization_id uuid primary key references public.organizations(id), receipt_validity_minutes int not null default 20 check (receipt_validity_minutes between 1 and 1440), points_per_litre numeric(8,2) not null default 1, mobile_mismatch_policy text not null default 'REJECT' check (mobile_mismatch_policy in ('REJECT','REVIEW')), require_vehicle_on_receipt boolean not null default true, fraud_threshold_review int not null default 50, allowed_clock_skew_seconds int not null default 90, updated_at timestamptz not null default now());

create table public.user_profiles (user_id uuid primary key references auth.users(id) on delete cascade, organization_id uuid references public.organizations(id), role public.app_role not null default 'USER', name text not null, mobile_number text not null, status public.account_status not null default 'ACTIVE', created_at timestamptz not null default now(), updated_at timestamptz not null default now(), unique (mobile_number));
create table public.manager_stations (manager_id uuid not null references public.user_profiles(user_id) on delete cascade, station_id uuid not null references public.stations(id), primary key (manager_id, station_id));

create table public.vehicles (vehicle_id uuid primary key default gen_random_uuid(), user_id uuid not null references public.user_profiles(user_id) on delete cascade, vehicle_number text not null, vehicle_type text not null, nickname text, created_at timestamptz not null default now(), updated_at timestamptz not null default now(), active boolean not null default true);
create unique index vehicles_one_active_number_per_user on public.vehicles(user_id, vehicle_number) where active;

create table public.fuel_transactions (id uuid primary key default gen_random_uuid(), station_id uuid not null references public.stations(id), invoice_number text not null, receipt_token text unique, fcc_id text, fip_number text, nozzle_number text, product text not null, rate_per_litre numeric(10,2) not null, volume_litre numeric(10,3) not null, amount numeric(10,2) not null, vehicle_number text, mobile_number text, transaction_at timestamptz not null, printed_at timestamptz, source text not null default 'POS_IMPORT', created_at timestamptz not null default now(), unique(station_id, invoice_number));

create table public.fuel_receipts (id uuid primary key default gen_random_uuid(), transaction_id uuid references public.fuel_transactions(id), invoice_number text not null, receipt_token text unique, station_id uuid not null references public.stations(id), fcc_id text, fip_number text, nozzle_number text, product text not null, rate_per_litre numeric(10,2) not null, volume_litre numeric(10,3) not null, amount numeric(10,2) not null, vehicle_number text, mobile_number text, transaction_date date generated always as ((transaction_at at time zone 'Asia/Kolkata')::date) stored, transaction_time time generated always as ((transaction_at at time zone 'Asia/Kolkata')::time) stored, transaction_at timestamptz not null, printed_at timestamptz, gst_number text, source text not null default 'POS_IMPORT', status public.receipt_status not null default 'VERIFIED', redeemed_by uuid references public.user_profiles(user_id), redeemed_at timestamptz, created_at timestamptz not null default now(), unique(station_id, invoice_number));
create index fuel_receipts_search_idx on public.fuel_receipts(station_id, invoice_number, vehicle_number, mobile_number, transaction_at desc);

create table public.receipt_images (id uuid primary key default gen_random_uuid(), user_id uuid not null references public.user_profiles(user_id), receipt_id uuid references public.fuel_receipts(id), storage_path text not null, sha256_hash text not null, byte_size int not null, content_type text not null, created_at timestamptz not null default now());
create index receipt_images_hash_idx on public.receipt_images(sha256_hash);

create table public.verification_attempts (id uuid primary key default gen_random_uuid(), user_id uuid not null references public.user_profiles(user_id), vehicle_id uuid references public.vehicles(vehicle_id), station_id uuid references public.stations(id), receipt_id uuid references public.fuel_receipts(id), idempotency_key text not null, extracted jsonb not null default '{}', risk_signals jsonb not null default '{}', decision text not null, result_message text not null, ip_hash text, created_at timestamptz not null default now(), unique(user_id, idempotency_key));
create index verification_attempts_velocity_idx on public.verification_attempts(user_id, created_at desc);

create table public.receipt_redemptions (id uuid primary key default gen_random_uuid(), receipt_id uuid not null references public.fuel_receipts(id), user_id uuid not null references public.user_profiles(user_id), vehicle_id uuid not null references public.vehicles(vehicle_id), redeemed_at timestamptz not null default now(), status public.redemption_status not null, idempotency_key text not null, created_at timestamptz not null default now(), unique(user_id, idempotency_key));
create unique index receipt_one_successful_redemption on public.receipt_redemptions(receipt_id) where status = 'SUCCESS';

create table public.points_ledger (id uuid primary key default gen_random_uuid(), user_id uuid not null references public.user_profiles(user_id), vehicle_id uuid references public.vehicles(vehicle_id), receipt_id uuid references public.fuel_receipts(id), transaction_id uuid references public.fuel_transactions(id), points int not null, type text not null check (type in ('EARN','REDEEM','ADJUST','BONUS')), description text not null, created_at timestamptz not null default now());
create unique index points_one_award_per_receipt on public.points_ledger(receipt_id) where type in ('EARN','BONUS');

create table public.offers (id uuid primary key default gen_random_uuid(), organization_id uuid not null references public.organizations(id), title text not null, description text not null, image_url text, points_bonus int default 0, minimum_purchase numeric(10,2), applicable_fuel text, applicable_vehicle text, start_at timestamptz not null, expires_at timestamptz not null, terms text, status text not null default 'ACTIVE', created_at timestamptz not null default now(), updated_at timestamptz not null default now());
create table public.offer_claims (id uuid primary key default gen_random_uuid(), offer_id uuid not null references public.offers(id), user_id uuid not null references public.user_profiles(user_id), claimed_at timestamptz not null default now(), status text not null default 'CLAIMED', unique(offer_id, user_id));

create table public.fraud_events (id uuid primary key default gen_random_uuid(), user_id uuid references public.user_profiles(user_id), receipt_id uuid references public.fuel_receipts(id), event_type text not null, severity text not null check (severity in ('LOW','MEDIUM','HIGH','CRITICAL')), details jsonb not null default '{}', created_at timestamptz not null default now());
create table public.manual_reviews (id uuid primary key default gen_random_uuid(), receipt_id uuid references public.fuel_receipts(id), attempt_id uuid references public.verification_attempts(id), assigned_to uuid references public.user_profiles(user_id), status public.review_status not null default 'OPEN', manager_notes text, decision_by uuid references public.user_profiles(user_id), decided_at timestamptz, created_at timestamptz not null default now());
create table public.audit_logs (id uuid primary key default gen_random_uuid(), actor_user_id uuid references public.user_profiles(user_id), action public.audit_action not null, target_table text, target_id uuid, result text not null, metadata jsonb not null default '{}', created_at timestamptz not null default now());

alter table public.user_profiles enable row level security;
alter table public.vehicles enable row level security;
alter table public.fuel_receipts enable row level security;
alter table public.receipt_redemptions enable row level security;
alter table public.points_ledger enable row level security;
alter table public.offers enable row level security;
alter table public.offer_claims enable row level security;
alter table public.verification_attempts enable row level security;
alter table public.fraud_events enable row level security;
alter table public.manual_reviews enable row level security;
alter table public.audit_logs enable row level security;

create or replace function public.current_role() returns public.app_role language sql stable security definer as $$ select role from public.user_profiles where user_id = auth.uid() $$;
create or replace function public.is_owner() returns boolean language sql stable security definer as $$ select public.current_role() = 'OWNER' $$;
create or replace function public.is_manager() returns boolean language sql stable security definer as $$ select public.current_role() in ('MANAGER','OWNER') $$;

create policy own_profile on public.user_profiles for select using (user_id = auth.uid() or public.is_manager());
create policy own_vehicles on public.vehicles for all using (user_id = auth.uid() or public.is_manager()) with check (user_id = auth.uid() or public.is_manager());
create policy own_redemptions on public.receipt_redemptions for select using (user_id = auth.uid() or public.is_manager());
create policy own_points on public.points_ledger for select using (user_id = auth.uid() or public.is_manager());
create policy active_offers_read on public.offers for select using (status = 'ACTIVE' or public.is_manager());
create policy owner_offer_write on public.offers for all using (public.is_owner()) with check (public.is_owner());
create policy own_offer_claims on public.offer_claims for all using (user_id = auth.uid() or public.is_manager()) with check (user_id = auth.uid() or public.is_manager());
create policy manager_receipts on public.fuel_receipts for select using (public.is_manager());
create policy own_attempts on public.verification_attempts for select using (user_id = auth.uid() or public.is_manager());
create policy manager_fraud on public.fraud_events for select using (public.is_manager());
create policy manager_reviews on public.manual_reviews for all using (public.is_manager()) with check (public.is_manager());
create policy owner_audit on public.audit_logs for select using (public.is_owner());



create or replace function public.normalize_mobile(input text) returns text
language sql immutable as $$
  select case
    when regexp_replace(coalesce(input,''), '\D', '', 'g') ~ '^91[0-9]{10}$' then right(regexp_replace(input, '\D', '', 'g'), 10)
    when regexp_replace(coalesce(input,''), '\D', '', 'g') ~ '^0[0-9]{10}$' then right(regexp_replace(input, '\D', '', 'g'), 10)
    else regexp_replace(coalesce(input,''), '\D', '', 'g')
  end
$$;

create or replace function public.normalize_vehicle(input text) returns text
language sql immutable as $$
  select upper(regexp_replace(coalesce(input,''), '[^A-Za-z0-9]', '', 'g'))
$$;

create or replace function public.redeem_receipt_atomic(
  p_user_id uuid,
  p_vehicle_id uuid,
  p_station_id uuid,
  p_invoice_number text,
  p_receipt_token text,
  p_amount numeric,
  p_volume_litre numeric,
  p_idempotency_key text,
  p_extracted jsonb default '{}'::jsonb
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_existing receipt_redemptions%rowtype;
  v_receipt fuel_receipts%rowtype;
  v_vehicle vehicles%rowtype;
  v_profile user_profiles%rowtype;
  v_settings app_settings%rowtype;
  v_points int;
  v_attempt uuid;
begin
  if auth.uid() is distinct from p_user_id and not public.is_manager() then
    raise exception 'Forbidden' using errcode = '42501';
  end if;

  select * into v_existing from receipt_redemptions
    where user_id = p_user_id and idempotency_key = p_idempotency_key;
  if found then
    return jsonb_build_object('decision', case when v_existing.status='SUCCESS' then 'APPROVED' else v_existing.status::text end, 'redemption_id', v_existing.id, 'points_awarded', v_existing.points_awarded, 'idempotent', true);
  end if;

  select * into v_profile from user_profiles where user_id = p_user_id and status='ACTIVE';
  if not found then raise exception 'User not active'; end if;
  select * into v_vehicle from vehicles where vehicle_id = p_vehicle_id and user_id = p_user_id and active for update;
  if not found then raise exception 'Vehicle not found'; end if;

  select * into v_receipt from fuel_receipts
    where station_id = p_station_id and (invoice_number = p_invoice_number or (p_receipt_token is not null and receipt_token = p_receipt_token))
    for update;

  if not found then
    insert into verification_attempts(user_id, vehicle_id, station_id, idempotency_key, extracted, risk_signals, decision, result_message)
    values(p_user_id, p_vehicle_id, p_station_id, p_idempotency_key, p_extracted, '{"invoice_match":false}'::jsonb, 'REJECTED', 'Invalid receipt') returning id into v_attempt;
    return jsonb_build_object('decision','REJECTED','message','We could not verify this Parchi with Kalash Filling Stations.');
  end if;

  select s.* into v_settings from app_settings s join stations st on st.organization_id=s.organization_id where st.id=v_receipt.station_id;

  if exists(select 1 from receipt_redemptions where receipt_id = v_receipt.id and status='SUCCESS') then
    insert into receipt_redemptions(receipt_id,user_id,vehicle_id,status,idempotency_key,points_awarded) values(v_receipt.id,p_user_id,p_vehicle_id,'FAILED',p_idempotency_key,0);
    return jsonb_build_object('decision','REJECTED','message','This Parchi has already been redeemed.');
  end if;
  if now() - v_receipt.transaction_at > make_interval(mins => coalesce(v_settings.receipt_validity_minutes,20)) then
    update fuel_receipts set status='EXPIRED' where id=v_receipt.id;
    insert into receipt_redemptions(receipt_id,user_id,vehicle_id,status,idempotency_key,points_awarded) values(v_receipt.id,p_user_id,p_vehicle_id,'FAILED',p_idempotency_key,0);
    return jsonb_build_object('decision','REJECTED','message','This Parchi has expired. Parchis can only be redeemed within '||coalesce(v_settings.receipt_validity_minutes,20)||' minutes of the fuel transaction.');
  end if;
  if v_receipt.transaction_at > now() + make_interval(secs => coalesce(v_settings.allowed_clock_skew_seconds,90)) then
    return jsonb_build_object('decision','REJECTED','message','We could not verify this Parchi with Kalash Filling Stations.');
  end if;
  if public.normalize_vehicle(coalesce(v_receipt.vehicle_number,'')) <> public.normalize_vehicle(v_vehicle.vehicle_number) then
    return jsonb_build_object('decision','REJECTED','message','Vehicle number doesn''t match this Parchi.');
  end if;
  if v_receipt.mobile_number is not null and public.normalize_mobile(v_receipt.mobile_number) <> public.normalize_mobile(v_profile.mobile_number) then
    if coalesce(v_settings.mobile_mismatch_policy,'REJECT') = 'REVIEW' then
      insert into receipt_redemptions(receipt_id,user_id,vehicle_id,status,idempotency_key,points_awarded) values(v_receipt.id,p_user_id,p_vehicle_id,'REVIEW_REQUIRED',p_idempotency_key,0) returning id into v_attempt;
      insert into manual_reviews(receipt_id,status) values(v_receipt.id,'OPEN');
      return jsonb_build_object('decision','REVIEW_REQUIRED','message','This Parchi needs manager review before points are awarded.');
    end if;
    return jsonb_build_object('decision','REJECTED','message','This Parchi is linked to a different mobile number.');
  end if;
  if abs(v_receipt.amount - p_amount) > 0.01 or abs(v_receipt.volume_litre - p_volume_litre) > 0.005 then
    return jsonb_build_object('decision','REJECTED','message','We could not verify this Parchi with Kalash Filling Stations.');
  end if;

  v_points := greatest(1, floor(v_receipt.volume_litre * coalesce(v_settings.points_per_litre,1))::int);
  insert into receipt_redemptions(receipt_id,user_id,vehicle_id,status,idempotency_key,points_awarded) values(v_receipt.id,p_user_id,p_vehicle_id,'SUCCESS',p_idempotency_key,v_points) returning * into v_existing;
  insert into points_ledger(user_id,vehicle_id,receipt_id,transaction_id,points,type,description) values(p_user_id,p_vehicle_id,v_receipt.id,v_receipt.transaction_id,v_points,'EARN','Verified fuel purchase');
  update fuel_receipts set status='REDEEMED', redeemed_by=p_user_id, redeemed_at=now() where id=v_receipt.id;
  insert into audit_logs(actor_user_id, action, target_table, target_id, result) values(p_user_id,'POINTS_AWARDED','fuel_receipts',v_receipt.id,'SUCCESS');
  return jsonb_build_object('decision','APPROVED','redemption_id',v_existing.id,'receipt_id',v_receipt.id,'points_awarded',v_points,'message','Parchi verified. Points added successfully.');
end;
$$;

-- Receipt redemption must be implemented by a SECURITY DEFINER RPC/Edge Function that:
-- 1. selects the fuel_receipts row FOR UPDATE,
-- 2. validates token/invoice/vehicle/mobile/amount/volume/timestamp against trusted POS data,
-- 3. inserts receipt_redemptions and points_ledger in one transaction,
-- 4. relies on receipt_one_successful_redemption and points_one_award_per_receipt as final safeguards.
