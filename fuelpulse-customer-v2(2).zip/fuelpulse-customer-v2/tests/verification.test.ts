import test from 'node:test';
import assert from 'node:assert/strict';
import { InMemoryStore } from '../server/store';
import { evaluateReceipt } from '../server/verification';
import { normalizeMobile, normalizeVehicleNumber } from '../server/normalization';
import { parseReceiptOcr } from '../server/ocrParser';
import type { FuelReceipt, UserProfile, Vehicle } from '../shared/types';

function fixture(offsetMinutes = -5) {
  const store = new InMemoryStore();
  const user: UserProfile = { user_id: 'u1', name: 'Yash', mobile_number: '9997874057', role: 'USER', status: 'ACTIVE' };
  const vehicle: Vehicle = { vehicle_id: 'v1', user_id: 'u1', vehicle_number: 'UP85AB1234', vehicle_type: 'Car', active: true };
  const tx = new Date(Date.UTC(2026, 8, 12, 8, 0, 0));
  tx.setMinutes(tx.getMinutes() + offsetMinutes);
  const receipt: FuelReceipt = { id: 'r1', invoice_number: '2315221261305163', receipt_token: 'secure-token', station_id: 's1', fcc_id: '301093661', fip_number: '03', nozzle_number: '03', product: 'Petrol', rate_per_litre: 101.39, volume_litre: 3.45, amount: 350, vehicle_number: 'UP85AB1234', mobile_number: '9997874057', transaction_at: tx.toISOString(), source: 'POS_IMPORT', status: 'VERIFIED' };
  store.users.set(user.user_id, user); store.vehicles.set(vehicle.vehicle_id, vehicle); store.receipts.set(receipt.id, receipt);
  return { store, user, vehicle, now: new Date(Date.UTC(2026, 8, 12, 8, 0, 0)) };
}

test('normalizes mobile and vehicle identities', () => {
  assert.equal(normalizeMobile('+91 9997874057'), '9997874057');
  assert.equal(normalizeMobile('09997874057'), '9997874057');
  assert.equal(normalizeVehicleNumber('up 85 ab 1234'), 'UP85AB1234');
});

test('parses sample IndianOil parchi fields without hard-coding values', () => {
  const parsed = parseReceiptOcr('IndianOil\nKALASH FILLING STATION\nInv. No: 2315221261305163\nFCC ID: 301093661\nFIP No.: 03\nNozzle No.: 03\nProduct: Petrol\nRate(Rs/L): 101.39\nVolume(L): 3.45\nAmount(Rs): 350.00\nVehicle No: UP85AB1234\nMobile No: +91 9997874057\nDate: 10/09/26\nTime: 12:13\nPrinted on:10/09/26 12:15');
  assert.equal(parsed.invoice_number, '2315221261305163');
  assert.equal(parsed.product, 'Petrol');
  assert.equal(parsed.amount, 350);
  assert.equal(parsed.volume_litre, 3.45);
  assert.equal(parsed.vehicle_number, 'UP85AB1234');
  assert.equal(parsed.mobile_number, '9997874057');
});

test('valid receipt awards points exactly once', () => {
  const { store, user, vehicle, now } = fixture();
  const result = evaluateReceipt(store, { user, vehicle, stationId: 's1', idempotencyKey: 'idem-valid-1', now, extracted: { invoice_number: '2315221261305163', amount: 350, volume_litre: 3.45, vehicle_number: 'UP85AB1234', mobile_number: '9997874057' } });
  assert.equal(result.decision, 'APPROVED');
  assert.equal(result.pointsAwarded, 3);
  assert.equal(store.pointsBalance('u1'), 3);
});

test('duplicate idempotency returns original result without double points', () => {
  const { store, user, vehicle, now } = fixture();
  const args = { user, vehicle, stationId: 's1', idempotencyKey: 'same-key-1', now, extracted: { invoice_number: '2315221261305163', amount: 350, volume_litre: 3.45, vehicle_number: 'UP85AB1234' } };
  evaluateReceipt(store, args); const again = evaluateReceipt(store, args);
  assert.equal(again.decision, 'APPROVED');
  assert.equal(store.pointsBalance('u1'), 3);
});

test('already redeemed receipt is rejected for replay attack', () => {
  const { store, user, vehicle, now } = fixture();
  evaluateReceipt(store, { user, vehicle, stationId: 's1', idempotencyKey: 'first-user', now, extracted: { invoice_number: '2315221261305163', amount: 350, volume_litre: 3.45, vehicle_number: 'UP85AB1234' } });
  const other = { ...user, user_id: 'u2' }; const otherVehicle = { ...vehicle, user_id: 'u2', vehicle_id: 'v2' };
  const result = evaluateReceipt(store, { user: other, vehicle: otherVehicle, stationId: 's1', idempotencyKey: 'second-user', now, extracted: { invoice_number: '2315221261305163', amount: 350, volume_litre: 3.45, vehicle_number: 'UP85AB1234' } });
  assert.equal(result.decision, 'REJECTED');
  assert.match(result.userMessage, /already been redeemed/i);
});

test('expired, future, invalid, mismatched receipts are rejected', () => {
  let f = fixture(-25);
  assert.equal(evaluateReceipt(f.store, { user:f.user, vehicle:f.vehicle, stationId:'s1', idempotencyKey:'expired-1', now:f.now, extracted:{ invoice_number:'2315221261305163', amount:350, volume_litre:3.45, vehicle_number:'UP85AB1234' }}).signals.receipt_expired, true);
  f = fixture(5);
  assert.equal(evaluateReceipt(f.store, { user:f.user, vehicle:f.vehicle, stationId:'s1', idempotencyKey:'future-1', now:f.now, extracted:{ invoice_number:'2315221261305163', amount:350, volume_litre:3.45, vehicle_number:'UP85AB1234' }}).decision, 'REJECTED');
  f = fixture();
  assert.equal(evaluateReceipt(f.store, { user:f.user, vehicle:f.vehicle, stationId:'s1', idempotencyKey:'invalid-1', now:f.now, extracted:{ invoice_number:'bad' }}).decision, 'REJECTED');
  f = fixture();
  assert.equal(evaluateReceipt(f.store, { user:f.user, vehicle:{...f.vehicle, vehicle_number:'UP85CD5678'}, stationId:'s1', idempotencyKey:'vehicle-mismatch', now:f.now, extracted:{ invoice_number:'2315221261305163', amount:350, volume_litre:3.45 }}).signals.vehicle_match, false);
  f = fixture();
  assert.equal(evaluateReceipt(f.store, { user:{...f.user, mobile_number:'8888874057'}, vehicle:f.vehicle, stationId:'s1', idempotencyKey:'mobile-mismatch', now:f.now, extracted:{ invoice_number:'2315221261305163', amount:350, volume_litre:3.45, vehicle_number:'UP85AB1234' }}).signals.mobile_match, false);
  f = fixture();
  assert.equal(evaluateReceipt(f.store, { user:f.user, vehicle:f.vehicle, stationId:'s1', idempotencyKey:'amount-mismatch', now:f.now, extracted:{ invoice_number:'2315221261305163', amount:500, volume_litre:3.45, vehicle_number:'UP85AB1234' }}).signals.amount_match, false);
  f = fixture();
  assert.equal(evaluateReceipt(f.store, { user:f.user, vehicle:f.vehicle, stationId:'s2', idempotencyKey:'station-mismatch', now:f.now, extracted:{ invoice_number:'2315221261305163', amount:350, volume_litre:3.45, vehicle_number:'UP85AB1234' }}).decision, 'REJECTED');
});

test('duplicate image and velocity anomalies require review, not blind approval', () => {
  const { store, user, vehicle, now } = fixture();
  store.imageHashes.set('2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824', new Set(['someone-else']));
  const review = evaluateReceipt(store, { user, vehicle, stationId: 's1', idempotencyKey: 'dup-img-1', now, imageBytes: Buffer.from('hello'), extracted: { invoice_number:'2315221261305163', amount:350, volume_litre:3.45, vehicle_number:'UP85AB1234' } });
  assert.equal(review.decision, 'REVIEW_REQUIRED');
});
