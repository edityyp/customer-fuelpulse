import test from 'node:test';
import assert from 'node:assert/strict';
import { assertRole, generateReceiptToken, maskInvoice, maskMobile } from '../server/security';

test('roles are limited to USER, MANAGER, OWNER and enforce escalation', () => {
  assert.throws(() => assertRole('USER', 'MANAGER'), /Forbidden/);
  assert.doesNotThrow(() => assertRole('MANAGER', 'MANAGER'));
  assert.doesNotThrow(() => assertRole('OWNER', 'MANAGER'));
});

test('tokens are cryptographically random opaque values', () => {
  const a = generateReceiptToken();
  const b = generateReceiptToken();
  assert.notEqual(a, b);
  assert.ok(a.length >= 32);
  assert.ok(!a.includes('1001'));
});

test('PII masking hides mobile and invoice details', () => {
  assert.equal(maskMobile('9997874057'), '******4057');
  assert.equal(maskInvoice('2315221261305163'), '••••••••••••5163');
});
