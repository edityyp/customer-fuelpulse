import { mkdirSync, copyFileSync, writeFileSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
mkdirSync('dist', { recursive: true });
copyFileSync('index.html', 'dist/index.html');
copyFileSync('src/app.js', 'dist/app.js');
copyFileSync('src/styles.css', 'dist/styles.css');
const manifest = { name: 'FuelPulse Customer V2', generatedAt: new Date().toISOString(), files: ['index.html','app.js','styles.css'] };
writeFileSync('dist/build-manifest.json', JSON.stringify(manifest, null, 2));
console.log('Built dist/ with independent FuelPulse Customer V2 app');
