import type { OcrReceiptFields, FuelProduct } from '../shared/types';
import { normalizeMobile, normalizeVehicleNumber, rupeeAmount } from './normalization';

function first(text: string, patterns: RegExp[]): string | undefined {
  for (const p of patterns) {
    const match = text.match(p);
    if (match?.[1]) return match[1].trim();
  }
  return undefined;
}

function num(text: string, patterns: RegExp[]): number | undefined {
  const value = first(text, patterns);
  return value ? rupeeAmount(value) : undefined;
}

function product(value?: string): FuelProduct | undefined {
  if (!value) return undefined;
  const v = value.toLowerCase();
  if (v.includes('petrol') || v.includes('ms')) return 'Petrol';
  if (v.includes('diesel') || v.includes('hsd')) return 'Diesel';
  if (v.includes('cng')) return 'CNG';
  return 'Other';
}

export function parseReceiptOcr(raw: string): OcrReceiptFields {
  const text = raw.replace(/\r/g, '\n').replace(/[|]/g, 'I');
  const mobileRaw = first(text, [/Mobile\s*No\.?\s*[:\-]?\s*(\+?\d[\d\s-]{8,})/i]);
  const vehicleRaw = first(text, [/Vehicle\s*No\.?\s*[:\-]?\s*([A-Z]{2}\s*\d{1,2}\s*[A-Z]{0,3}\s*\d{3,4})/i]);
  const productRaw = first(text, [/Product\s*[:\-]?\s*([A-Za-z]+)/i]);
  let mobile_number: string | undefined;
  let vehicle_number: string | undefined;
  try { if (mobileRaw && !/not\s*entered/i.test(mobileRaw)) mobile_number = normalizeMobile(mobileRaw); } catch {}
  try { if (vehicleRaw && !/not\s*entered/i.test(vehicleRaw)) vehicle_number = normalizeVehicleNumber(vehicleRaw); } catch {}

  return {
    invoice_number: first(text, [/(?:Inv\.?|Invoice)\s*(?:No\.?)?\s*[:\-]?\s*([A-Z0-9-]{5,64})/i]),
    fcc_id: first(text, [/FCC\s*ID\s*[:\-]?\s*([A-Z0-9-]+)/i]),
    fip_number: first(text, [/FIP\s*No\.?\s*[:\-]?\s*([A-Z0-9-]+)/i]),
    nozzle_number: first(text, [/Nozzle\s*No\.?\s*[:\-]?\s*([A-Z0-9-]+)/i]),
    product: product(productRaw),
    rate_per_litre: num(text, [/Rate\s*\(?Rs\/?L\)?\s*[:\-]?\s*([₹\d,.]+)/i, /Rate\s*[:\-]?\s*([₹\d,.]+)/i]),
    volume_litre: num(text, [/Volume\s*\(?L\)?\s*[:\-]?\s*([\d,.]+)/i]),
    amount: num(text, [/Amount\s*\(?Rs\)?\s*[:\-]?\s*([₹\d,.]+)/i, /Amount\s*[:\-]?\s*([₹\d,.]+)/i]),
    vehicle_number,
    mobile_number,
    date: first(text, [/Date\s*[:\-]?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/i]),
    time: first(text, [/Time\s*[:\-]?\s*(\d{1,2}:\d{2}(?::\d{2})?)/i]),
    printed_at: first(text, [/Printed\s*on\s*[:\-]?\s*([\d\/\-]+\s+\d{1,2}:\d{2}(?::\d{2})?)/i])
  };
}
