import type { FuelReceipt, OcrReceiptFields, RedemptionResult, RiskSignals, UserProfile, Vehicle } from '../shared/types';
import { normalizeInvoice, normalizeMobile, normalizeVehicleNumber } from './normalization';
import { maskInvoice, maskMobile, sha256 } from './security';
import type { InMemoryStore } from './store';
import { randomUUID } from 'node:crypto';

function closeEnough(a?: number, b?: number, tolerance = 0.01): boolean {
  return typeof a === 'number' && typeof b === 'number' && Math.abs(a - b) <= tolerance;
}

function defaultSignals(): RiskSignals {
  return {
    receipt_valid: false,
    receipt_expired: false,
    already_redeemed: false,
    vehicle_match: false,
    mobile_match: 'NOT_PRESENT',
    invoice_match: false,
    amount_match: false,
    volume_match: false,
    station_match: false,
    timestamp_match: false,
    token_valid: 'NOT_PRESENT',
    duplicate_attempt: false,
    velocity_anomaly: false,
    account_risk: false
  };
}

export interface RedemptionInput {
  user: UserProfile;
  vehicle: Vehicle;
  stationId: string;
  extracted: OcrReceiptFields;
  idempotencyKey: string;
  now?: Date;
  imageBytes?: Buffer;
}

export function evaluateReceipt(store: InMemoryStore, input: RedemptionInput): RedemptionResult {
  const original = store.redemptionByIdempotency(input.user.user_id, input.idempotencyKey);
  if (original) {
    return {
      decision: original.status === 'SUCCESS' ? 'APPROVED' : original.status,
      userMessage: original.status === 'SUCCESS' ? 'Parchi already verified.' : 'This verification request was already processed.',
      receiptId: original.receipt_id,
      redemptionId: original.id,
      pointsAwarded: original.points_awarded,
      signals: { ...defaultSignals(), duplicate_attempt: true, already_redeemed: original.status === 'SUCCESS', receipt_valid: original.status === 'SUCCESS' }
    };
  }

  const now = input.now ?? new Date();
  const recent = store.attemptsByUser.get(input.user.user_id)?.filter(ts => now.getTime() - ts < 60_000) ?? [];
  recent.push(now.getTime());
  store.attemptsByUser.set(input.user.user_id, recent);

  const signals = defaultSignals();
  signals.velocity_anomaly = recent.length > 10;
  if (input.imageBytes) {
    const hash = sha256(input.imageBytes);
    const users = store.imageHashes.get(hash) ?? new Set<string>();
    signals.duplicate_attempt = users.size > 0 && !users.has(input.user.user_id);
    users.add(input.user.user_id);
    store.imageHashes.set(hash, users);
  }

  let receipt: FuelReceipt | undefined;
  try {
    if (input.extracted.receipt_token) {
      receipt = store.findReceiptByToken(input.extracted.receipt_token);
      signals.token_valid = Boolean(receipt);
    }
    if (!receipt && input.extracted.invoice_number) {
      const invoice = normalizeInvoice(input.extracted.invoice_number);
      receipt = store.findReceiptByInvoice(input.stationId, invoice);
      signals.invoice_match = Boolean(receipt);
    }
  } catch {
    return reject('Invalid receipt', 'We could not verify this Parchi with Kalash Filling Stations.', signals);
  }

  if (!receipt) return reject('Invalid receipt', 'We could not verify this Parchi with Kalash Filling Stations.', signals);

  signals.station_match = receipt.station_id === input.stationId;
  signals.invoice_match = receipt.invoice_number === normalizeInvoice(input.extracted.invoice_number ?? receipt.invoice_number);
  signals.amount_match = input.extracted.amount === undefined || closeEnough(input.extracted.amount, receipt.amount);
  signals.volume_match = input.extracted.volume_litre === undefined || closeEnough(input.extracted.volume_litre, receipt.volume_litre, 0.005);
  signals.token_valid = input.extracted.receipt_token ? input.extracted.receipt_token === receipt.receipt_token : 'NOT_PRESENT';
  signals.already_redeemed = Boolean(store.successfulRedemption(receipt.id));

  const transactionAt = new Date(receipt.transaction_at);
  const ageMs = now.getTime() - transactionAt.getTime();
  signals.receipt_expired = ageMs > store.settings.receipt_validity_minutes * 60_000;
  signals.timestamp_match = transactionAt.getTime() <= now.getTime() + store.settings.allowed_clock_skew_seconds * 1000;

  const trustedVehicle = receipt.vehicle_number ? normalizeVehicleNumber(receipt.vehicle_number) : undefined;
  const selectedVehicle = normalizeVehicleNumber(input.vehicle.vehicle_number);
  signals.vehicle_match = Boolean(trustedVehicle) && trustedVehicle === selectedVehicle;
  if (!trustedVehicle && !store.settings.require_vehicle_on_receipt) signals.vehicle_match = true;

  if (receipt.mobile_number) {
    signals.mobile_match = normalizeMobile(receipt.mobile_number) === normalizeMobile(input.user.mobile_number);
  }

  signals.receipt_valid = signals.station_match && signals.invoice_match && signals.amount_match && signals.volume_match && signals.timestamp_match && !signals.receipt_expired && !signals.already_redeemed && signals.vehicle_match && signals.mobile_match !== false && signals.token_valid !== false && !signals.velocity_anomaly;

  if (signals.already_redeemed) return reject('Already used', 'This Parchi has already been redeemed.', signals, receipt);
  if (signals.receipt_expired) return reject('Expired', `This Parchi has expired. Parchis can only be redeemed within ${store.settings.receipt_validity_minutes} minutes of the fuel transaction.`, signals, receipt);
  if (!signals.timestamp_match) return reject('Future receipt', 'We could not verify this Parchi with Kalash Filling Stations.', signals, receipt);
  if (!signals.vehicle_match) return reject('Vehicle mismatch', "Vehicle number doesn't match this Parchi.", signals, receipt);
  if (signals.mobile_match === false) {
    if (store.settings.mobile_mismatch_policy === 'REVIEW') return review('Mobile review', 'This Parchi needs manager review before points are awarded.', signals, receipt, store, input);
    return reject('Mobile mismatch', 'This Parchi is linked to a different mobile number.', signals, receipt);
  }
  if (!signals.amount_match || !signals.volume_match || !signals.station_match || signals.token_valid === false) return reject('Mismatch', 'We could not verify this Parchi with Kalash Filling Stations.', signals, receipt);
  if (signals.velocity_anomaly || signals.duplicate_attempt) return review('Risk review', 'This Parchi needs manager review before points are awarded.', signals, receipt, store, input);

  const points = Math.max(1, Math.floor(receipt.volume_litre * store.settings.points_per_litre));
  const redemptionId = randomUUID();
  store.redemptions.set(redemptionId, {
    id: redemptionId,
    receipt_id: receipt.id,
    user_id: input.user.user_id,
    vehicle_id: input.vehicle.vehicle_id,
    status: 'SUCCESS',
    idempotency_key: input.idempotencyKey,
    points_awarded: points,
    created_at: now.toISOString()
  });
  store.ledger.set(randomUUID(), {
    id: randomUUID(), user_id: input.user.user_id, vehicle_id: input.vehicle.vehicle_id, receipt_id: receipt.id,
    points, type: 'EARN', description: `Fuel purchase ${maskInvoice(receipt.invoice_number)}`, created_at: now.toISOString()
  });
  receipt.status = 'REDEEMED';
  receipt.redeemed_by = input.user.user_id;
  receipt.redeemed_at = now.toISOString();

  return { decision: 'APPROVED', userMessage: 'Parchi verified. Points added successfully.', receiptId: receipt.id, redemptionId, pointsAwarded: points, maskedInvoice: maskInvoice(receipt.invoice_number), maskedMobile: maskMobile(receipt.mobile_number), signals };
}

function reject(_reason: string, userMessage: string, signals: RiskSignals, receipt?: FuelReceipt): RedemptionResult {
  return { decision: 'REJECTED', userMessage, receiptId: receipt?.id, maskedInvoice: maskInvoice(receipt?.invoice_number), maskedMobile: maskMobile(receipt?.mobile_number), signals };
}

function review(_reason: string, userMessage: string, signals: RiskSignals, receipt: FuelReceipt, store: InMemoryStore, input: RedemptionInput): RedemptionResult {
  const redemptionId = randomUUID();
  store.redemptions.set(redemptionId, { id: redemptionId, receipt_id: receipt.id, user_id: input.user.user_id, vehicle_id: input.vehicle.vehicle_id, status: 'REVIEW_REQUIRED', idempotency_key: input.idempotencyKey, points_awarded: 0, created_at: (input.now ?? new Date()).toISOString() });
  return { decision: 'REVIEW_REQUIRED', userMessage, receiptId: receipt.id, redemptionId, maskedInvoice: maskInvoice(receipt.invoice_number), maskedMobile: maskMobile(receipt.mobile_number), signals };
}
