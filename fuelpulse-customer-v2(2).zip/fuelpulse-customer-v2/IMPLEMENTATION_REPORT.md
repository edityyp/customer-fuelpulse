# FuelPulse Customer V2 Implementation Report

## Existing repository inspection

The supplied FuelPulse app is a combined station/staff/customer system with Fastify, Vite, PostgreSQL/Supabase migrations, ALPR, loyalty and customer portal files. V2 was created in a separate folder/repository and does not edit the supplied application.

Reusable ideas carried forward:

- Fastify API structure and rate limiting pattern
- React/Vite frontend stack
- Security headers and server-side validation
- Loyalty points concept

Not carried forward:

- Employee/staff dashboard terminology
- Plate-first customer lookup as the primary user flow
- Existing production Supabase schema
- Existing production auth/database coupling

## New V2 application

Created as `fuelpulse-customer-v2` with:

- User mobile-first rewards UI
- Manager fraud/verification dashboard
- Owner control dashboard
- OCR parser for IndianOil/Kalash Parchi fields
- Secure receipt verification service
- Role and PII helpers
- Supabase migration with RLS, constraints, audit tables, review tables and points ledger
- Test suite for critical business/security rules

## Critical business rule implementation

The implementation follows:

Parchi → QR/OCR extraction → server verification against trusted transaction record → fraud/duplicate checks → redeem once → immutable points ledger.

OCR data is explicitly treated as extraction only and cannot approve points without a matching backend receipt/transaction.

## Limitations / next deployment steps

A real Supabase project cannot be created from this sandbox without your Supabase credentials. The project includes reproducible migrations and `.env.example`; deploy them to a newly created Supabase project only.

For production, implement the redemption function as a Supabase Edge Function or server endpoint using a database transaction/row lock (`SELECT ... FOR UPDATE`) and the included unique constraints as final safeguards.
